#include<stdio.h>

int main()
{
	int a=10;
	int b=20;
	
	swap(&a,&b);
	printf("\n a=%d",a);
	printf("\n b=%d",b);
}

swap(int *x, int *y)
{
	int t;
	t=*x;
	*x=*y;
	*y=t;
}



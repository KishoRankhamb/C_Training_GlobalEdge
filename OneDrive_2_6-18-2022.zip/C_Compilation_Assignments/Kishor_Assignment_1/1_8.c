/*Write a program to count blanks, tabs, and newlines.*/
#include<stdio.h>
int main(void)
{
	int space ,tab,newline;
	space=0;
	tab=0;
	newline=0;
	int c;
	while((c=getchar())!=EOF)
	{
	if((c==' '))
	   space++; 
	else if((c=='\t'))
		tab++;
	else if((c=='\n'))
		newline++;
	}
	printf("\n space =%d\n",space);
	printf("\n tab =%d\n",tab);
	printf("\n newline =%d\n",newline);

	return 0;
}



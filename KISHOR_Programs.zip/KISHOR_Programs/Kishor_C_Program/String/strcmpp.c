#include<stdio.h>
#include<string.h>
int main(void)
{
	char str1[10]="KISHOR";
	char str2[10]="RANKHAMB";
	int i;	
	if(str2[i] == str1[i])
	{	
		printf("\n Both are same");
	}
	else
	{
		printf("\n Both are not same");
	}
	return 0;
}

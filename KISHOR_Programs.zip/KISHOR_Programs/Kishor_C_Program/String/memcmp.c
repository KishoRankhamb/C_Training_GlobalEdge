//memcmp function 
//syntax:- int memcmp(const void *str1, const void *str2, size_t n)

#include <stdio.h>
#include <string.h>

int main () {
   char str1[10];
   char str2[10];
   int ret;

   memcpy(str1, "kishor", 6);
   memcpy(str2, "RANKHAMB", 8);

   ret = memcmp(str1, str2, 5);

   if(ret > 0) {
      printf("str2 is less than str1");
   } else if(ret < 0) {
      printf("str1 is less than str2");
   } else {
      printf("str1 is equal to str2");
   }
   
   return(0);
}

#include<stdio.h>
int main()
{
	int a=256;
	char c='A';
	int *ptr=&a;
//	printf("%lu \n",ptr);
//	ptr++;
//	printf("%lu \n",ptr++);
	char *cptr1=&a;
//	cptr1++;
//	printf("%lu \n",cptr1++);
	printf("*cptr1=%d",*cptr1);
//	char *cptr=&c;
	return 0;
}

/*ex:1.14 Write a program to print a histogram of the frequencies of different characters in its input.*/
#include<stdio.h>
int main()
{
  int c;

  while((c=getchar()) != EOF)
  {
    if( c == ' ' || c == '\n' || c == '\t')
      putchar('\n');
    else
      putchar('*');
  }
  return 0;
}

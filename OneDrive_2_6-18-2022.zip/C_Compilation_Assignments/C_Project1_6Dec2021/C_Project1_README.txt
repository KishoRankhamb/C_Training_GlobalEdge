C Project 1 : Title - Fix the compilation errors/warnings & Memory Leaks
========================================================================
I. Task 1 : Make the compilation successful
	i. How to compile?
	   STEP1: cd Project
	   STep2: make
	ii. Fix the compilation errors

	iii. Take a screen shot of screen and upload it to your assignment folder (file name should be: Cproject1_6Dec2021_task1_output.jpg)
	or Copy paste the terminal ouput to Cproject1_6Dec2021_task1_output.txt and upload it.

II. Task 2 : Fix all the Warnings
	i. After fixing all the warnings, Take a screen shot of screen and upload it to your assignment folder (file name should be: Cproject1_6Dec2021_task2_output.jpg)
	or Copy paste the terminal ouput to Cproject1_6Dec2021_task2_output.txt and upload it.

III. Task 3 : Add "-WAll" option in the make file and fix all the warnings	
	i. How to add "-WAll" in make file?
	   $vi Makefile 
	     Ex- LFLAGS = -Wall -L/usr/lib
	ii. Fix the compilation warnings
	iii. After fixing all the warnings, Take a screen shot of screen and upload it to your assignment folder (file name should be: Cproject1_6Dec2021_task3_output.jpg)
	or Copy paste the terminal ouput to Cproject1_6Dec2021_task3_output.txt and upload it.

IV. Task 4: Fix the Static Code Analyzer i.e. cppcheck issues
	i. How to compile the code with cppcheck?
	   go to src directory
	   $cd src
	ii. how to run the code with cppcheck?
	   STEP1 :sudo apt-get install cppcheck
	   STEP2 :src$ ccpcheck Mainfile.c
	iii. Fix the warnings reported by cppcheck?
	iv. After fixing all the warnings, Take a screen shot of screen and upload it to your assignment folder (file name should be: Cproject1_6Dec2021_task4_output.jpg)
	or Copy paste the terminal ouput to Cproject1_6Dec2021_task4_output.txt and upload it.
	
V. Task 5: Fix the Memory leaks
	i. How to run the code with valgrind?
	   STEP1: cd Project
	   STEP2: vi Makefile
	   STEP3: Add -g flags in Makefile
	    eg: LFLAGS = -Wall -g -L/usr/lib
	ii. How to view the valgrind report?
	    valgrind Exefile
	iii. Fix the memory leaks reported by Valgrind?
	iv. After fixing all the warnings, Take a screen shot of screen and upload it to your assignment folder (file name should be: Cproject1_6Dec2021_task5_output.jpg)
	or Copy paste the terminal ouput to Cproject1_6Dec2021_task5_output.txt and upload it.
	


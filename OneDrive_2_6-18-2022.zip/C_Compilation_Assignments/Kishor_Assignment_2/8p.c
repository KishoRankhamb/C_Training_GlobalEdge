/*palindrome number program*/

#include<stdio.h>
int main(void)
{
 int a, b, sum=0, temp;
 printf("Enter the limit:");
 scanf("%d", &a);
 while(a>0)
 {
  b=a%10;
  sum=sum*10+b;
  a=a/10;
 }
 //a=temp;
 temp = a;
 if(a==temp)
 {
	 printf("Palindrome");
 }
 else
 {
	printf("not palindrome");
 }
return 0;
}

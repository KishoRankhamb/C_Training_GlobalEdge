#include<stdio.h>
int main()
{
	int a=35;
	int *b;
	b=&a;
	printf("Value of a=%d\n",a);
	printf("Value of b=%d\n",b);
	printf("Address of a=%u\n",&a);	
	printf("Address of b=%u\n",&b);
	return 0;


}

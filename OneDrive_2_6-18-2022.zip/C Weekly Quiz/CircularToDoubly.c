#include <stdio.h>
#include <stdlib.h>

struct node {
  int data;
  struct node *next;
} *head;
 
void initialize(){
    head = NULL;
}

void insert(int num) {
    
    struct node* newNode = (struct node*) malloc(sizeof(struct node));
    newNode->data  = num;
    
    newNode->next = head;
    
    head = newNode;
    printf("Inserted Element : %d\n", num);
}
 
void convertToCircularLL(struct node *head){
    
    if(head == NULL){
        printf("Error : Invalid Input !!!!\n");
        return INT_MIN;
    }
    struct node *temp = head;
    while(temp->next != NULL){
        temp = temp->next;
    }
     
    temp->next = head;
}

void printCircularLinkedList(struct node *head) {
    struct node *temp = head;
    do {
        printf("%d ", temp->data);
        temp = temp->next;
    } while(temp != head);
}
  
int main() {
    initialize();
    /* Creating a linked List*/
    insert(1);  
    insert(2); 
    insert(3); 
    insert(4);
    insert(5);
     
    convertToCircularLL(head);
     
    /* Printing Circular Linked List */
    printCircularLinkedList(head);
    return 0;
}
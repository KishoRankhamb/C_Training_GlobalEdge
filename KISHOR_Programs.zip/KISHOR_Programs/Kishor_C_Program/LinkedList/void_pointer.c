#include<stdio.h>
int main()
{
	int a=0;
	void *ptr=&a;
//	printf("%d\n",*ptr); //derefernce to void pointer
	printf("%d\n",*(int *)ptr);
	printf("%u\n",ptr);
	printf("%d\n", sizeof(void));
	return 0;
}

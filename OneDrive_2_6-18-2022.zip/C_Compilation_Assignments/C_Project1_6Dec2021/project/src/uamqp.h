// Copyright (c) Microsoft. All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.

#ifndef UAMQP_H
#define UAMQP_H

/* This header includes all the uAMQP headers
Unless advanced cherrypicking of which functionality is to be used,
a user can always inlcude this header */

#include "amqp_definitions.h"
#include "amqp_frame_codec.h"
#include "amqp_management.h"
#include "amqp_types.h"
#include "amqpvalue.h"
#include "amqpvalue_to_string.h"
#include "cbs.h"
#include "connection.h"
#include "frame_codec.h"
#include "header_detect_io.h"
#include "link.h"
#include "message.h"
#include "message_receiver.h"
#include "message_sender.h"
#include "messaging.h"
#include "sasl_anonymous.h"
#include "sasl_frame_codec.h"
#include "sasl_mechanism.h"
#include "sasl_server_mechanism.h"
#include "sasl_mssbcbs.h"
#include "sasl_plain.h"
#include "saslclientio.h"
#include "sasl_server_io.h"
#include "server_protocol_io.h"
#include "session.h"
#include "socket_listener.h"

#endif /* UAMQP_H */


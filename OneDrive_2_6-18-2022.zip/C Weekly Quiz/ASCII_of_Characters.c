// C program to print
// ASCII Value of Character
#include <stdio.h>
int main()
{
	char c[20];
    int n;
	printf("Enter the no of characters present in an array:");
    scanf("%d", &n);
    
    printf("\n Enter Array Elements:");
    scanf("%s",&c);  
	for(int i=0;i<11;i++)
	{
	    printf("The ASCII value is=%d\n",c[i]);
	}
	return 0;
}

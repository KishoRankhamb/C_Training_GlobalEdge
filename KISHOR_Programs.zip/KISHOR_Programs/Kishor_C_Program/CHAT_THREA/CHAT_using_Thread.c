#include <signal.h> 
#include <stdio.h> 
#include <stdlib.h> 
#include <string.h> 
#include <sys/ipc.h> 
#include <sys/shm.h> 
#include <sys/types.h> 
#include <unistd.h> 
#include <pthread.h>

#define FILLED 0 
#define Ready 1 
#define NotReady -1
#define key 12345;

pthread_t thread1;
pthread_t thread2;

void *thread_fun1(void *args);
void *thread_fun2(void *args);

int shmid;

struct share1{
    char buff[100];
    int status, pid1, pid2;
};


struct share1* attptr1;

/*struct share2{
    char buff[100];
    int status, pid1, pid2;
};
struct share2* attptr2;*/

/*void handler(int signum)
{
    if(signum == SIGUSR1)
    {
        printf("Received from User2: \n");
        puts(attptr1->buff);
    }
    
    if (signum == SIGUSR2) 
    { 

        printf("Received From User1: "); 

        puts(attptr1->buff); 
    } 
}*/

int main()
{
   shmid = shmget((key_t)12345, sizeof(struct share1), 0666|IPC_CREAT);
    pthread_create(&thread1, NULL, &thread_fun1, NULL);
    pthread_create(&thread2, NULL, &thread_fun2, NULL);
    pthread_join(thread1, NULL);
    pthread_join(thread2, NULL);
    //shmid = shmget((key_t)12345, sizeof(struct share1), 0666|IPC_CREAT);
    return 0;
}

void *thread_fun1(void *arg)
{
    int tid = pthread_self();
    attptr1 = (struct share1*)shmat(shmid, NULL, 0);
    attptr1->pid1 = tid;
    attptr1->status = NotReady;
    
   // signal(SIGUSR1, handler);
    while(1)
    {
    while(attptr1->status != Ready)
        continue;
    sleep(1);
   // puts(attptr1->buff);
   
    printf("\nUser2 RECEIVED: %sReply: ",attptr1->buff);
   // printf("\0");
    fgets(attptr1->buff, 100, stdin);
   // printf("User2 Sent: %s", attptr1->buff);
    attptr1->status = FILLED;
//    kill(attptr1->pid2, SIGUSR2);
    }
    //shmdt((void*)attptr1);
}

void *thread_fun2(void *args)
{
     int tid = pthread_self();
     attptr1= (struct share1*)shmat(shmid, NULL, 0);
     attptr1->pid2 = tid;
     attptr1->status = NotReady;
    // signal(SIGUSR2, handler);
    int i =0;
     while(1)
    {
    sleep(1);
    
    if(i==0){
       printf("START CONVERSATION\n");
       printf("User1: ");
    }
    else
    printf("\nUser1 RECEIVED: %sReply: ", attptr1->buff);
    
    fgets(attptr1->buff, 100, stdin);
    //(attptr1->buff) = attptr1->buff[(strlen(attptr1->buff)-1)];
   // printf("User1 Sent: %s", attptr1->buff); 
    i++;
    attptr1->status = Ready;
  //  kill(attptr1->pid1, SIGUSR1);
    while(attptr1->status == Ready)
        continue;
    }
    shmdt((void *)attptr1);
}

#include<stdio.h>
#include<string.h>

int main()
{
	char s1[]= "GlobalEdgeSoft",s2[100],i;
	printf("String s1: %s\n",s1);

	for(i=0;s1[i]!='\0';++i)
	{
		s2[i]=s1[i];
	}
	s2[i]='\0';
	printf("String s2:%s\n",s2);
	return 0;
}

#include<stdio.h>
int main()
{
//	int *ptr=NULL;
//	printf("%d\n",*ptr);
	printf("%lu\n",sizeof(void *));
	printf("%d\n",NULL);
	printf("%d\n",sizeof(NULL));
	return 0;
}

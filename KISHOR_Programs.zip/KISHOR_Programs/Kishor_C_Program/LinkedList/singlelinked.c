#include <stdio.h>
#include <stdlib.h>

struct node{
            int data;
            struct node *link;
};

struct node *head;

void insertbegin();
void insertlast();
void display();
void insertposition();
void deletebegin();
void deletelast();

//to insert the value at the begining
void insertbegin()
{
    struct node *ptr;
    int item;
    ptr = (struct node *) malloc(sizeof(struct node));
    
    printf("Enter element to be inserted in the begining:\n");
    scanf("%d",&item);

        ptr -> data = item;
        ptr -> link = head;
        head = ptr;
}

//to display
void display()
{
    struct node *ptr;
    ptr = head;

    if(ptr == NULL) {
                printf("EMPTY!\n");
    }
    else {
         while ( ptr != NULL) {
                    printf("\n%d\n",ptr -> data);
                    ptr = ptr -> link;
        }
    }
}

void insertlast()
{
    struct node *ptr, *temp;
    int item;

    ptr = (struct node *) malloc(sizeof(struct node));
    printf("Enter the element to be inserted at the end:\n");
    scanf("%d", &item);

    ptr -> data = item;

    if(head == NULL) {
        ptr -> link = NULL;
        head = ptr;
    }
    else {
        temp = head;

        while(temp -> link != NULL) {
            temp = temp -> link;
        }
        temp -> link = ptr;
        ptr -> link = NULL;
    }
}

void insertposition()
{
    int i, pos, item;
    struct node *ptr, *temp;
    ptr = (struct node*) malloc(sizeof(struct node));

    printf("Enter the position where the element has to be inserted:\n");
    scanf("%d", &pos);

    printf("Enter the element to be inserted:\n");
    scanf("%d", &item);

    ptr -> data = item;
    temp = head;

    for(i = 0; i < pos; i++) {
        temp = temp -> link;

        if(temp == NULL) {
            printf("Cannot be inserted\n");
            return;
        }
    }
    ptr -> link = temp -> link;
    temp -> link = ptr;
}

void deletebegin()
{
    struct node *ptr;
    
    if(head == NULL) {
        printf("List is Empty\n");
    }
    else {
        ptr = head;
        head = ptr -> link;
        free(ptr);

        printf("Element deleted!\n");
    }
}


void deletelast()
{
    struct node *ptr, *ptr1;

    if(head == NULL){
        printf("Empty!\n");
    }
    else if(head -> link == NULL) {
        head = NULL;
        free(head);
        
        printf("Deleted the only elemene\n");
    }
    else {
        ptr = head;
        while (ptr -> link != NULL)
        {
            ptr1 = ptr;
            ptr = ptr -> link;
        }
        ptr1 -> link = NULL;
        free(ptr);

        printf("Deleted\n");
    }
}



    
    

int main(void)
{
    int ch;
    while(1)
    {   
        printf("\nSELECT:\n1.Insert in the begining\n");
        printf("2.Display all the elments\n");
        printf("3.Insert in the end\n");
        printf("4.Insert in the specific location\n");
        printf("5.Delete the first element\n");
        printf("6.Delete the last element\n");
        printf("7.Exit\n");
        scanf("%d", &ch);

        switch(ch){
            case 1: insertbegin();
                    break;
            case 2: display();
                    break;
            case 3: insertlast();
                    break;
            case 4: insertposition();
                    break;
            case 5: deletebegin();
                    break;
            case 6: deletelast();
                    break;
            case 7: exit(1);

        }
    }
}

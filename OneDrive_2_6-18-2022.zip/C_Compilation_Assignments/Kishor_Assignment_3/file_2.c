#include<stdio.h>
extern int i;

int temp(void)
{
	int i=20;
	printf ("i value in temp function is [%d]\n", i);
	//i = 20;
	return 0;
}




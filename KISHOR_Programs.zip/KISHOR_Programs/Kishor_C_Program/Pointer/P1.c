#include<stdio.h>

int main()
{
	unsigned int i=3;
	printf("Address of i=%u\n",&i);
	printf("Value of i=%d\n",i);
	return 0;
}

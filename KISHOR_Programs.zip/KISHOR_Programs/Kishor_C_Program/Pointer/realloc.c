#include<stdio.h>
#include<stdlib.h>
int main()
{
	int i,n;
	int *ptr;
	n=5;

	//Dynamically allocated memory using calloc
	ptr=(int*) calloc (n, sizeof(int));

	if(ptr == NULL)
	{
		printf("\n Memory not allocated ");
		exit(0);
	}
	else
	{
		printf("\n Allocated Memory");
		for(i=0;i<n;++i)
		{
			ptr[i]=i+1;
		}
		printf("\n Array elemtns");
		printf("\n");
		for(i=0;i<n;++i)
		{
			printf("%d\n",ptr[i]);
		}
	}
	
	n=10;
	
	//Dynamically memory allocated using realloc
	ptr=realloc(ptr,n*sizeof(int));
	printf("\n Memory Successfully re-allocated using realloc");
	
	for(i=0;i<n;i++)
	{
		ptr[i]=i+1;
	}
	printf("\n Array Elements:");
	printf("\n");
	for(i=0;i<n;i++)
	{
		printf("%d \n",ptr[i]);
	}
	free(ptr);
	return 0;

}

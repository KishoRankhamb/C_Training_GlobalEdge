#include<stdio.h>
#include<limits.h>
int main(void)
{
  printf("singed short max value:%d\n", SHRT_MAX);
  printf("signed short min value:%d\n ", SHRT_MIN);
  printf("unsinged short max value:%u\n ",USHRT_MAX);
  printf("unsigned int max value:%d\n ",UINT_MAX);
  
}

/* by Modify Operation Using increment and decrement*/
#include<stdio.h>
int main(void)
{
 int a=10 ,b=20, c, d;
 c=(++a) *(b++);
 d=--a * b--;
 printf("%d\n%d\n%d\n ", a,b,c);
 printf("%d\n%d\n%d\n ", a,b,d);
}

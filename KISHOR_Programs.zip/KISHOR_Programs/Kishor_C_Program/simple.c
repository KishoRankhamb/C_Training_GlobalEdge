#include<stdio.h>
int main()
{
	extern int i;
	int i;
	int i=20;
	return 0;
}

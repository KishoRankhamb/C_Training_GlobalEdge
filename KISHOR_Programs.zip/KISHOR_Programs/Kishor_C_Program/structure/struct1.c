#include<stdio.h>
#include<stdlib.h>
struct emp{
	int emp_id;
	char emp_name;
	float emp_sal;
}e1;


int main()
{
	e1.emp_id=10;
	e1.emp_name="KISHOR";
	e1.emp_sal=20.00;
	scanf("%d %s %f \n" ,e1.emp_id,e1.emp_name,e1.emp_sal);
	printf("%d %s %f \n" ,e1.emp_id,e1.emp_name,e1.emp_sal);
	return 0;
}

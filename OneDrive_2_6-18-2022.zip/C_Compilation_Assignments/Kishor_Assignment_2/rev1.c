#include<stdio.h>
#include<string.h>
int main(void)
{
 int i, j, count=0;
 char str[100], rev[100];
 printf("Enter any string: ");
 scanf("%s", str);
 printf("Before reverse string:%s\n", str);
 count=strlen(str);
 j=count-1;
 for(i=0;i<count;i++)
 {
  rev[i]=str[j];
  j--;
 }

printf("After reverse string:%s\n", rev);
}

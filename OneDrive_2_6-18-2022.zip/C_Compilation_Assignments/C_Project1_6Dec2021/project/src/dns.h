#include<stdio.h>       //printf
#include<string.h>      //strlen
#include<stdlib.h>      //malloc
#include<sys/socket.h>  //you know what this is for
#include<arpa/inet.h>   //inet_addr , inet_ntoa , ntohs etc
#include<netinet/in.h>
#include<unistd.h>      //getpid


void ngethostbyname (unsigned char* , int);
void ChangetoDnsNameFormat (unsigned char*,unsigned char*);
unsigned char* ReadName (unsigned char*,unsigned char*,int*);
void get_dns_servers();

char *dns_resolver(char*);

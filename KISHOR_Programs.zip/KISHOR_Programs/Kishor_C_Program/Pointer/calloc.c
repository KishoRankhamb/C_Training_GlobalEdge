#include<stdio.h>
#include<stdlib.h>
int main()
{
	int *ptr;
	int n,i;
	n=5;
	printf("\n Enter Number of elements:%d\n",n);

	//Dynamically allocated memory using calloc
	ptr=(int *)calloc(n, sizeof(int));
	

	if(ptr == NULL)
	{
		printf("\n Memory Not  Allocated");
		exit(0);
	}	
	else
	{
		printf("\n Memory Allocated using calloc");
		for(i=0;i<n;++i)
		{
			ptr[i]=i+1;
		}
		printf("\n The elements of the array: ");
		printf("\n");
		for(i=0;i<n;++i)
		{
			printf("%d \n",ptr[i]);
		}
	}	
	return 0;
} 

#include <stdio.h>
#include "/home/mohseen/Downloads/Assignment_3/file_2.c"
int i;

int main()
{
	i = 10;
	temp();
	printf("i value in main function is [%d]\n", i);
}

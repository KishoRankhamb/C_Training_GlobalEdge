#include <stdio.h>

void Strfun(char *ptr)
{
    printf("The String is : %s",ptr);
}
int main()
{
	
	char buff[20]="Hello Function";
	
	// Passing string to Function
	Strfun(buff);
	
	return 0;
}
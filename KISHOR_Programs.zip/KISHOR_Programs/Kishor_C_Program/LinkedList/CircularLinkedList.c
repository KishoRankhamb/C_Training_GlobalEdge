#include<stdio.h>
#include<stdlib.h>

//structure of Linked List node

struct node{
	int info;
	struct node* next;
};

//Pointer for Last Node
struct node* last = NULL;

//Function to add new node at begin
void insertAtFront()
{
	int data; //Stores the number to be inserted
	struct node* temp;
	
	temp=(struct node*)malloc(sizeof(struct node));
	
	//Input data
	printf("Enter Data to be inserted at Front \n");
	scanf("%d", &data);
	
	//If the new node is the only node in the list
	if(last == NULL)	
	{
		temp->info= data;
		temp->next= temp;
		last = temp;
	}
	//Else last node contains reference of the new node and new node contains reference of previous first node
	else
	{
		temp->info = data;
		temp->next = last->next;
		last->next = temp; // Last node has reference of the new node temp	
	}
}

void insertAtEnd()
{

	int data;
	struct node* temp;
	
	temp=(struct node*)malloc(sizeof(struct node));
	
	 //Input data
        printf("Enter Data to be inserted at  End \n");
        scanf("%d", &data);

	//If the new node is the only node in the list
	if(last == NULL)
        {
                temp->info= data;
                temp->next= temp;
                last = temp;
        }
	//Else new node will be the last node and will contain the reference of the head node(previous added new node)
	else
	{
		temp-> info = data;
		temp-> next = last->next;
		last-> next = temp;
		last = temp;
	}
}

void viewlist()
{
	if(last == NULL)
	{
		printf("\n List is empty");
	}
	else
	{
		struct node* temp;
		temp = last->next;
		do{
			printf("\n Data Inserted = %d",temp->info);
			temp = temp->next;
		}while(temp!=last->next);
	}
}


int main()
{
	insertAtFront();
	insertAtFront();
	insertAtFront();

	insertAtEnd();
	insertAtEnd();
	insertAtEnd();
	
	viewlist();
	
	return 0;
}		

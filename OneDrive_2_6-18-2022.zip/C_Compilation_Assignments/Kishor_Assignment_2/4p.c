#include<stdio.h>
int a=10; //program scope
void check(int a)
{
	printf("%d\n",a);
}
int main(void)
{
	
	 int a=20; //function scope
  	 {
     		int a=20;    //block scope
     		printf("%d\n",a);	
                {
  	   		a=a+10;
		}
    		printf("%d\n",a);
         	check(a);

	 }
	 printf("inside main=%d",a);

}

/*void check()
{
            printf("%d\n", a);

}*/
 

#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <stdint.h>
#include "lock.h"
#include "tlsio.h"
#include "optimize_size.h"
#include "xlogging.h"
#include "crt_abstractions.h"
#include "shared_util_options.h"
#include "gballoc.h"
#include "const_defines.h"
#include "x509_crt.h"
//#define AF_INET6 3
//#define CONNECTION_STRING "HostName=xxxxxx.azure-devices.net;DeviceId=xxxxxxx;x509=true"
#define CONNECTION_STRING "HostName=9116Hub.azure-devices.net;DeviceId=Demo_Device_1;SharedAccessKey=jd2HA7IOFc7u4AeLNGfQSW6Og0vVQzzaWa0wRhb00x0="
#define MESSAGE_COUNT \
  5 ///< Number of D2C messages sent to Azure Hub and also minimum number of C2D messages to be received by application
#define CLIENT_PORT 4002 ///< Client port

typedef enum TLSIO_VERSION_TAG {
        VERSION_1_0,
        VERSION_1_1,
        VERSION_1_2,
} TLSIO_VERSION;

struct CRYPTO_dynlock_value {
        LOCK_HANDLE lock;
};

typedef enum TLSIO_STATE_TAG {
        TLSIO_STATE_NOT_OPEN,
        TLSIO_STATE_OPENING_UNDERLYING_IO,
        TLSIO_STATE_IN_HANDSHAKE,
        // TLSIO_STATE_HANDSHAKE_FAILED is an ephemeral state signalling successful socket
        //   // operation but with rejected handshake. The tlsio will never be in this state
        //     // at the start of any of the API calls.
        TLSIO_STATE_HANDSHAKE_FAILED,
        TLSIO_STATE_OPEN,
        TLSIO_STATE_CLOSING,
        TLSIO_STATE_ERROR
} TLSIO_STATE;

typedef struct TLS_IO_INSTANCE_TAG {
        XIO_HANDLE underlying_io;
        ON_BYTES_RECEIVED on_bytes_received;
        ON_IO_OPEN_COMPLETE on_io_open_complete;
        ON_IO_CLOSE_COMPLETE on_io_close_complete;
        ON_IO_ERROR on_io_error;
        void *on_bytes_received_context;
        void *on_io_open_complete_context;
        void *on_io_close_complete_context;
        void *on_io_error_context;
        TLSIO_STATE tlsio_state;
        char *certificate;
        const char *x509_certificate;
        const char *x509_private_key;
        const char *ca_root;
        int socket_id;
} TLS_IO_INSTANCE;

//TLSIO_CONFIG tls_io_conf;

static const char *const OPTION_UNDERLYING_IO_OPTIONS = "underlying_io_options";

#define SSL_DO_HANDSHAKE_SUCCESS 1

//unsigned char recv_buffer[1046];
//int sent_flag = 0;


static void *tlsio_ssl_CloneOption(const char *, const void *);
int tlsio_openssl_init(void);
static void tlsio_ssl_DestroyOption(const char *, const void *);
//static void indicate_open_complete(TLS_IO_INSTANCE *, IO_OPEN_RESULT);
static void close_ssl_instance(TLS_IO_INSTANCE *);
static void on_underlying_io_close_complete(void *);
//static int decode_ssl_received_bytes(TLS_IO_INSTANCE *);
static int ConnecttoNetwork(TLS_IO_INSTANCE *, uint8_t, char *, int, int);
CONCRETE_IO_HANDLE tlsio_ssl_create(void *);
void tlsio_ssl_destroy(CONCRETE_IO_HANDLE);
int tlsio_ssl_open(CONCRETE_IO_HANDLE, ON_IO_OPEN_COMPLETE, void *, ON_BYTES_RECEIVED, void *, ON_IO_ERROR, void *);
int tlsio_ssl_close(CONCRETE_IO_HANDLE, ON_IO_CLOSE_COMPLETE, void *);
int tlsio_ssl_send(CONCRETE_IO_HANDLE, const void *, size_t, ON_SEND_COMPLETE, void *);
void tlsio_ssl_dowork(CONCRETE_IO_HANDLE);
int tlsio_ssl_setoption(CONCRETE_IO_HANDLE, const char *, const void *);
static OPTIONHANDLER_HANDLE tlsio_ssl_retrieveoptions(CONCRETE_IO_HANDLE);
const IO_INTERFACE_DESCRIPTION *tlsio_openssl_get_interface_description(void);

static bool is_an_opening_state(TLSIO_STATE state);
static void *tlsio_ssl_CloneOption(const char *name, const void *value);
int tlsio_openssl_init(void);
static void tlsio_ssl_DestroyOption(const char *name, const void *value);
//static void log_ERR_get_error(const char *message);
//static STATIC_VAR_UNUSED struct CRYPTO_dynlock_value *ssl_dynamic_locks_create_cb(const char *file, int line);
/*static STATIC_VAR_UNUSED void ssl_dynamic_locks_destroy_cb(struct CRYPTO_dynlock_value *dynlock_value,
                                                           const char *file,
                                                           int line);*/
//static void indicate_error(TLS_IO_INSTANCE *tls_io_instance);
//static void indicate_open_complete(TLS_IO_INSTANCE *tls_io_instance, IO_OPEN_RESULT open_result);
static void close_ssl_instance(TLS_IO_INSTANCE *tls_io_instance);
static void on_underlying_io_close_complete(void *context);
//static void on_underlying_io_open_complete(void *context, IO_OPEN_RESULT open_result);
//static void on_underlying_io_error(void *context);
//static int decode_ssl_received_bytes(TLS_IO_INSTANCE *tls_io_instance);
//static void on_underlying_io_bytes_received(void *context, const unsigned char *buffer, size_t size);
//static int add_certificate_to_store(TLS_IO_INSTANCE *tls_io_instance, const char *certValue);
static int ConnecttoNetwork(TLS_IO_INSTANCE *tls_io_instance, uint8_t flags, char *addr, int dst_port, int src_port);
CONCRETE_IO_HANDLE tlsio_ssl_create(void *io_create_parameters);
void tlsio_ssl_destroy(CONCRETE_IO_HANDLE tls_io);
int tlsio_ssl_open(CONCRETE_IO_HANDLE tls_io,
                   ON_IO_OPEN_COMPLETE on_io_open_complete,
                   void *on_io_open_complete_context,
                   ON_BYTES_RECEIVED on_bytes_received,
                   void *on_bytes_received_context,
                   ON_IO_ERROR on_io_error,
                   void *on_io_error_context);
int tlsio_ssl_close(CONCRETE_IO_HANDLE tls_io, ON_IO_CLOSE_COMPLETE on_io_close_complete, void *callback_context);
/*int tlsio_ssl_send(CONCRETE_IO_HANDLE tls_io,
                   const void *buffer,
                   size_t size,
                   ON_SEND_COMPLETE on_send_complete,
                   void *callback_context);*/
void tlsio_ssl_dowork(CONCRETE_IO_HANDLE tls_io);
int tlsio_ssl_setoption(CONCRETE_IO_HANDLE tls_io, const char *optionName, const void *value);
static OPTIONHANDLER_HANDLE tlsio_ssl_retrieveoptions(CONCRETE_IO_HANDLE handle);
const IO_INTERFACE_DESCRIPTION *tlsio_openssl_get_interface_description(void);

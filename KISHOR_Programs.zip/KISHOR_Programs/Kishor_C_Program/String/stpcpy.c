#include <string.h>
#include <stdio.h>     
int main(void)
{
           char buffer[20];
           char *to = buffer;

           to = stpcpy(to, "kishor");
           to = stpcpy(to, "Rankhamb");
           printf("%s\n", buffer);       
}

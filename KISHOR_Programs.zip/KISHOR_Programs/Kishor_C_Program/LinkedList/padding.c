#include<stdio.h>
struct padd{
	char a; //1 byte
        char b; //1 byte
        int  c; //4 byte
};
int main()
{
	//str1.c=20;
	//printf("%d\n",str1.c);
	struct padd s;	
	int size;
	printf("%c\n",sizeof(char));
	printf("%c\n",sizeof(char));
	printf("%d\n",sizeof(int));

	size=sizeof(s);
	printf("\n Size of structure:%d",size);
	

	return 0;
}

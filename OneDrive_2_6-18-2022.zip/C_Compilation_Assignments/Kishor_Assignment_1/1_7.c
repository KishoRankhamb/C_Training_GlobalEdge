/*Write a program to print the value of EOF.*/
#include<stdio.h>
int  main(void)
{
    printf("EOF=-1");
}

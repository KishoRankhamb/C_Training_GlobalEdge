#include<stdio.h>
int main(void)
{
    printf("c\n");
   return 0; 
}

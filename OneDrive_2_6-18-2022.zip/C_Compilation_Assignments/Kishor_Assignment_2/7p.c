/*Fibonacci series program*/

#include<stdio.h>
int main(void)
{
 int i, n, a=10, b=20, c;
 printf("Enter limit: ");
 scanf("%d",&n);
 for(i=0;i<n;i++)
 {
  printf("%d\n", a);
  c=a+b;
  a=b;
  b=c;

 }
}

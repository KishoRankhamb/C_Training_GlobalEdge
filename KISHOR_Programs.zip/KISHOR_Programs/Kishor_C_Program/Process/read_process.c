#include<stdio.h>
#include<sys/ipc.h>
#include<sys/msg.h>
#define MAX 100

struct mesg_buffer
{
	long mesg_type;
	char mesg_text[100];
}message;

int main()
{
	key_t key;
	int msgid;

	key=ftok("progfile",65);

	msgid=msgget(key,0666|IPC_CREAT);

	while(1)
	{
		msgrcv(msgid, &message, sizeof(message),1,0);

		printf("Data Received is : %s \n", message.mesg_text);

		fgets(message.mesg_text,MAX,stdin);

		printf("Data Send is : %s \n",message.mesg_text);
		msgsnd(msgid,&message,sizeof(message),0);
	}
	return 0;
}


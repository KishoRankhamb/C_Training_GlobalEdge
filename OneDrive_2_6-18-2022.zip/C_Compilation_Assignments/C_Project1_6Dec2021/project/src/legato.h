#include<stdio.h>

#define HSM_TYPE_SYMM_KEY 1
#define USE_PROV_MODULE 1
#define LWM2M_BOOTSTRAP 1
#define LWM2M_CLIENT_MODE 1
#define LWM2M_SUPPORT_SENML_JSON 1
#define use_prov_client 1


#include<stdio.h>
#include<stdlib.h>


void digit();
void character_with_Ascii();
void characters();
void symbols();
void floating();
void password();

int main(void)
{
	int ch;
	while(ch!=7)
	{
	//	printf("\n Keyboard Validation \n");
		printf("\n Choose Option from Menu given below \n");
		printf("\n 1.digit \n 2.character_With_Ascii \n 3.characters \n 4.symbols \n 5.Floating \n 6.password \n 7.exit ");
		printf("\n Enter your choice:");
		scanf("%d",&ch);
		
		switch(ch)
		{
			case 1:
			   digit();
			   break;
			case 2:
			    character_with_Ascii();
			    break;
			case 3:
			    characters();
			    break;
			case 4:
			    symbols();
			    break;
			case 5:
			    floating();
			    break;
			case 6:
			    password();
			    break;
			case 7:
			   exit(0);
			   break;

			default:
			   printf("\n Invalid Choice");

		}
	}
}

void digit()
{
 int d;  
 printf("\n Enter digit between 0 -9:");
 scanf("%d",&d);
 if(d<10)
  printf("\n Entered Value is digit");
 else
  printf("\n Entered Value is not digit");                 
}

void character_with_Ascii()
{
   char cha;
   printf("Enter a character:");
   scanf("%s",&cha);
  /*Alphabet check with ASCII */
   if(cha >= 65 && cha <= 90)
      printf("Upper Case Letter with ASCILL Value of %c= %d",cha,cha);
   else if(cha >= 97 && cha <= 122)
      printf("Lower Case letter");
   else if(cha >= 48 && cha <= 57)
      printf("\n You Pressed Number instead of character");
   else
      printf("Not an Character");
                          
}

void characters()
{
    char alphabet;
    /* Input character from user */
    printf("Enter any alphabet: ");
    scanf("%s", &alphabet);
    /* Alphabet check */
    if((alphabet >= 'a' && alphabet <= 'z') || (alphabet >= 'A' && alphabet <= 'Z'))
    {
        printf("'%c' is alphabet.", alphabet);
    }
    else
    {
        printf("It is not alphabet");
    }

}

void symbols()
{
  char sym;
  printf("\n Enter Symbol Value:");
  scanf("%s",&sym);
  if(sym == '@' + '%' | sym == '%'|sym == '$' | sym == '^'|sym == '&' | sym == '*'|sym == '#' | sym == ')')
	 printf("\n Entered Value is symbol");
  else
        printf("\n Entered value is not symbol");                    
}

void floating()
{
    char number[100];
    int flag = 0;

    printf("Enter the number to check itself: ");
    scanf("%s", number);

    //loop through each character of input
    for (int i = 0; number[i] != 0; i++) {
    //if decimal "." is fount, it means it is float
        if (number[i] == '.') {
            flag = 1;
            break;
        }
    }

    if (flag)
    {
       printf("\n%s is a floating-point number.\n", number);
    }
    else{
       printf("\n%s is not floating-point number.\n", number);
    }   
}

void password()
{
        char pass[20],ch;
        int i,number,special,capital,small;
        number=special=capital=small=0;
        printf("Enter Password>>");
        scanf("%s",&pass);
        for(i=0;pass[i]!='\0';i++)
        {
            if(pass[i]>='0' && pass[i]<='9')
            number=1;
            if(pass[i]>='a' && pass[i]<='z')
            small=1;
            if(pass[i]>='A' && pass[i]<='Z')
            capital=1;
            if(pass[i]=='!' || pass[i]=='@' || pass[i]=='#' || pass[i]=='$' || pass[i]=='%' || pass[i]=='*')
            special=1;
        }
        if(number==0 || special==0 || capital==0 || small==0)
	{ 
        	printf("\nInvalid Password"); 
	}
        else
	{
	        printf("\nValid Password");
	}    

}

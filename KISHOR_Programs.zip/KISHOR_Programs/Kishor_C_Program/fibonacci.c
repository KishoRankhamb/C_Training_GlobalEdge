#include<stdio.h>
int thiru(int n)
{
	if(n<=1)
		return n;
	return thiru(n-1) + thiru(n-2);
}
int main()
{
	int n=9;
	printf("%d",thiru(n));
	getchar();
	return 0;

}

#include<stdio.h>
int main()
{
	char *x;
	char **yy;	
	
	x=(char*)malloc(sizeof(char) * 50 );
	printf("%u\n",x);
	free(x);
	
	
	yy=(char**)malloc(sizeof(char*) * 50);
	printf("%u\n",yy);
	free(yy);
	printf("%lu \n",yy);

	
	return 0;
}

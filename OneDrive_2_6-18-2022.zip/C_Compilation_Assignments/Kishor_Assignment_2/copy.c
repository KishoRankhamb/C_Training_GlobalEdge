#include<stdio.h>
int main(void)
{
 int i;
 char str1[100], str2[100];
 scanf("%s", str1);
 for(i=0;str1[i]!='\0';i++)
 {
  str2[i]=str1[i];
 }
 str2[i]='\0';
 printf("Original string:%s\n", str1);
 printf("Copied string:%s\n", str2);
}

#include <stdio.h>
#include <string.h>

int main () 
{
   const char str[] = "http://www.google.com"; //This is the pointer to the block of memory where the search is performed
   const char ch = '.'; //This is the value to be passed as an int, but the function performs a byte per byte search using the unsigned char conversion of this value
   char *r;//This is the number of bytes to be analyzed

   r = memchr(str, ch, strlen(str));

   printf("String after |%c| is - |%s|\n", ch, r);

   return(0);
}

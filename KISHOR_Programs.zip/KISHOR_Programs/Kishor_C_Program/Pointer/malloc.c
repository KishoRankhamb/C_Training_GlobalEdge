#include<stdlib.h>
#include<stdio.h>
int main()
{
	int *ptr;
	int n,i;
	
	printf("\n Enter Number of elements:");
	scanf("%d",&n);
	printf("\n Entered Number if elements:%d\n",n);
	
	//Dynamically memory allocation
	ptr = (int *)malloc(n * sizeof(int));

	
	//Check if the memory has been allocated or not
	if(ptr == NULL)
	{
		printf("\n Memory Not Allocated ");
		exit(0);
	}
	else
	{
		printf("\n Memory Allocated Successfully");
		for(i=0;i<n;i++)
		{
			ptr[i]=i+1;
		}
		printf("\n The elements of the array is:");
		for(i=0;i<n;i++)
		{
			printf("%d\n",ptr[i]);
		}
	}
return 0;
}










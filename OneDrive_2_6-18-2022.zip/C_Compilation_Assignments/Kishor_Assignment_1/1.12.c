/*ex:1.12. Write a program that prints its input one word per line.*/
#include <stdio.h>
int main (int argc, char *argv[]) {
  int c,state,IN,OUT;
  IN = 1;
  OUT = 0;
  state = IN;
  while((c=getchar()) != EOF) {
    if(c==' ' || c == '\t')
      state=OUT;
    else if (state == OUT) {
      state=IN;
      putchar('\n');
      putchar(c);

    }
    else
      putchar(c);
  }
}

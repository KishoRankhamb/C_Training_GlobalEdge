/*Write a program to copy its input to its output, replacing each string of one or more blanks by a single blank.*/

#include<stdio.h>
int main(void)
{
int c;
while((c=getchar())!=EOF)
{
	if(c==' ')
	{
		if((c=getchar())==' ')
		putchar(' ');
	}
	putchar(c);
}
return 0;
}



#include <stdio.h>
#include <stdlib.h>

struct node {
            int data;
            struct node *link;
};

struct node *top;

int push();
int pop();
int display();

int main(void)
{
    int ch;
    while(1)
    {
    printf("Select:\n1.Push\n2.Pop\n3.Display\n4.Exit\n");
    scanf("%d", &ch);

    switch (ch)
        {
            case 1: push();
                    break;
            case 2: pop();
                    break;
            case 3: display();
                    break;
            case 4: exit(1);
                    break;
            default: printf("Invalid\n");
        }
    }
}



int push()
{
    int n;
    struct node *temp;
    temp = (struct node*) malloc(sizeof(struct node));

    printf("Enter element to be inserted:\n");
    scanf("%d", &n);

    temp -> data = n;
    temp -> link = 0;
    
    if(top == 0) {
          top = temp;
    }
    else {
        temp -> link = top;
        top = temp;
    }
}

int pop()
{
    int data;
    struct node *ptr;

    if(top == NULL) {
        printf("Underflow\n");
    }
    else {
        
        data = top -> data;
        ptr = top;

        printf("Deletion of %d successfull\n", data);

        top = top -> link;

        free(ptr);
    }
}

int display()
{
    struct node *ptr;

    if( top == NULL) {
                printf("Stack Empty!\n");
    }
    else {

        for(ptr = top; ptr != 0; ptr = ptr -> link)
        printf("%d\n", ptr -> data);
    }

}


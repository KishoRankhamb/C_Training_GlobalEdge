#include<stdio.h>
#include<stdlib.h>
int main()
{
	int *ptr=(int *)malloc(sizeof(int));
	printf("%lu \n",ptr);
	free(ptr);
	printf("%lu \n",ptr);
	ptr=NULL;
	printf("%lu \n",ptr);
	return 0;
}

